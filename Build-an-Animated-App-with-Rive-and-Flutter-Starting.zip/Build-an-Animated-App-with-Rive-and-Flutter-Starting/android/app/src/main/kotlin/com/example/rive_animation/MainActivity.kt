package com.example.rive_animation

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
